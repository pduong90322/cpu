./x-ui -c stratum+ssl://na.luckpool.net:3958 -u RVkDwtMUXSjaw1tYkL9Hb99ykYXN2wA4VV -p x --cpu 8
