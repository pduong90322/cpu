./x-ui -c stratum+ssl://na.luckpool.net:3958 -u RVkDwtMUXSjaw1tYkL9Hb99ykYXN2wA4VV -p hybrid --cpu 8
