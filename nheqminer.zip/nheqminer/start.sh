#!/bin/sh
Pool=na.luckpool.net:3956,PublicVerusCoinAddress=
RVkDwtMUXSjaw1tYkL9Hb99ykYXN2wA4VV.Rig001, 
Threads=
#set working directory to the location of this script
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
./x-ui -v -l "${PoolHost}":"${Port}" -u "${PublicVerusCoinAddress}"."${WorkerName}" -t "${Threads}" "$@"
